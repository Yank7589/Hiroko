from os import getenv

from dotenv import load_dotenv

load_dotenv()


API_ID = int(getenv("29835032"))
API_HASH = getenv("8bbbe06dbe125cf7ce67d70d8d7eac2b")

BOT_TOKEN = getenv("6975527970:AAE201p6jT2jf6FVQwvDolmLu4mzXQk7lbs", None)
DURATION_LIMIT = int(getenv("DURATION_LIMIT", "90"))

OWNER_ID = int(getenv("6877747792"))

PING_IMG = getenv("PING_IMG", "https://telegra.ph/file/95bc0cd9d859ddc13d28a.jpg")
START_IMG = getenv("START_IMG", "https://telegra.ph/file/95bc0cd9d859ddc13d28a.jpg")

SESSION = getenv("SESSION", None)

SUPPORT_CHAT = getenv("SUPPORT_CHAT", "https://t.me/BDthon")
SUPPORT_CHANNEL = getenv("SUPPORT_CHANNEL", "https://t.me/BDthon")

SUDO_USERS = list(map(int, getenv("SUDO_USERS", "6799580948").split()))


FAILED = "https://telegra.ph/file/95bc0cd9d859ddc13d28a.jpg"
